"""Open the bundled Still app locally using only Python's standard library."""

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
import webbrowser

APP = Path(__file__).with_name("Still.html")


class StillHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if urlsplit(self.path).path not in ("/", "/Still.html"):
            self.send_error(404)
            return
        body = APP.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *_args):
        pass


if __name__ == "__main__":
    if not APP.is_file():
        raise SystemExit("Extract the ZIP first: Still.html must be next to start.py.")
    try:
        server = ThreadingHTTPServer(("127.0.0.1", 8765), StillHandler)
    except OSError:
        raise SystemExit("Port 8765 is already in use. Close the previous Still launcher and try again.")
    print("Still is opening in your browser. Keep this window open; press Ctrl+C to stop.")
    print("The app is served only on this computer. Journal data stays in your browser.")
    webbrowser.open("http://127.0.0.1:8765")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
